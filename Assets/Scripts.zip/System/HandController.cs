using UnityEngine;

public sealed class HandController : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private Canvas rootCanvas;
    [SerializeField] private RectTransform dragLayer;                 // Full-stretch DragLayer
    [SerializeField] private RectTransform[] slots = new RectTransform[3]; // HandArea/Slot0..2

    [Header("Prefab")]
    [SerializeField] private PieceDragView dragPiecePrefab;

    [Header("Piece Pool")]
    [SerializeField] private PieceDefinition[] piecePool;

    private Camera uiCamera;
    private PieceDragView[] active = new PieceDragView[3];

    private void Awake()
    {
        uiCamera = (rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay) ? null : rootCanvas.worldCamera;
    }

    private void Start()
    {
        Spawn3();
    }

    private void Spawn3()
    {
        for (int i = 0; i < 3; i++)
        {
            var view = Instantiate(dragPiecePrefab, dragLayer, false);

            // Slot pivot position -> DragLayer local anchored position
            Vector2 slotScreen = RectTransformUtility.WorldToScreenPoint(uiCamera, slots[i].position);
            RectTransformUtility.ScreenPointToLocalPointInRectangle(dragLayer, slotScreen, uiCamera, out var slotLocal);

            // Slot size in DragLayer local units (robust, ������/ĵ���� ���� �ּ�ȭ)
            Vector2 slotSizeInDragLayer = GetRectSizeInTargetLocal(slots[i], dragLayer);

            view.SetHome(slotLocal, slotSizeInDragLayer);
            view.SetPiece(RandomPiece());

            view.OnPlaced += OnPlaced;

            active[i] = view;
        }
    }

    private void OnPlaced(PieceDragView view)
    {
        // Block Blast ����: ��ġ �����ϸ� ���� ���Կ� �� ���� ����
        view.SetPiece(RandomPiece());
    }

    private PieceDefinition RandomPiece()
    {
        if (piecePool == null || piecePool.Length == 0) return null;
        return piecePool[Random.Range(0, piecePool.Length)];
    }

    private static Vector2 GetRectSizeInTargetLocal(RectTransform rect, RectTransform targetSpace)
    {
        Vector3[] corners = new Vector3[4];
        rect.GetWorldCorners(corners);

        float minX = float.PositiveInfinity, maxX = float.NegativeInfinity;
        float minY = float.PositiveInfinity, maxY = float.NegativeInfinity;

        for (int i = 0; i < 4; i++)
        {
            Vector3 local = targetSpace.InverseTransformPoint(corners[i]);
            minX = Mathf.Min(minX, local.x);
            maxX = Mathf.Max(maxX, local.x);
            minY = Mathf.Min(minY, local.y);
            maxY = Mathf.Max(maxY, local.y);
        }

        return new Vector2(maxX - minX, maxY - minY);
    }
}
