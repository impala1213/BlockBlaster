﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class PieceDragView : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [Header("Refs")]
    [SerializeField] private GameController game;
    [SerializeField] private ScreenToGrid screenToGrid;
    [SerializeField] private Canvas rootCanvas;
    [SerializeField] private RectTransform dragLayer; // Full-stretch DragLayer
    [SerializeField] private CanvasGroup canvasGroup;

    [Header("Piece")]
    [SerializeField] private PieceDefinition piece;

    [Header("Visual")]
    [SerializeField] private Image blockPrefab; // BlockUnit.prefab (Image, raycast OFF)

    [Header("Tint Factors")]
    [SerializeField] private Color validFactor = new Color(0.6f, 1f, 0.6f, 1f);
    [SerializeField] private Color invalidFactor = new Color(1f, 0.6f, 0.6f, 1f);

    [Header("Hand Fit")]
    [Tooltip("Slot 안에서 너무 꽉 차지 않게 여백 비율(0.85~0.95 추천)")]
    [Range(0.6f, 1f)]
    [SerializeField] private float handPaddingFactor = 0.9f;

    public event Action<PieceDragView> OnPlaced;

    private RectTransform rect;
    private Camera uiCamera;

    // Home(슬롯) 정보
    private Vector2 homeAnchoredPos;
    private Vector2 homeSlotSize; // DragLayer local units
    private bool hasHome;

    // Hand scale (슬롯에 맞춰 자동 축소)
    private float handScale = 1f;

    // Drag
    private Vector2 grabOffset;

    // Visual blocks
    private Image[] blocks;
    private Color[] baseColors;
    private Vector2 lastCellSize;

    private void Awake()
    {
        rect = (RectTransform)transform;

        uiCamera = (rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay) ? null : rootCanvas.worldCamera;
        if (canvasGroup == null) canvasGroup = GetComponent<CanvasGroup>();

        if (screenToGrid != null)
            screenToGrid.OnRecalculated += HandleGridRecalculated;

        Canvas.ForceUpdateCanvases();
        if (screenToGrid != null) screenToGrid.Recalculate();
        BuildVisual();
    }

    private void OnDestroy()
    {
        if (screenToGrid != null)
            screenToGrid.OnRecalculated -= HandleGridRecalculated;
    }

    //  슬롯 위치 + 슬롯 크기까지 받음 (손패 느낌의 핵심)
    public void SetHome(Vector2 anchoredPos, Vector2 slotSizeInDragLayer)
    {
        hasHome = true;
        homeAnchoredPos = anchoredPos;
        homeSlotSize = slotSizeInDragLayer;

        RecomputeHandScale();   // slot에 맞춰 자동 축소
        SnapToHomePose();
    }

    public void SetPiece(PieceDefinition newPiece)
    {
        piece = newPiece;
        BuildVisual();
        ApplyTintFactor(Color.white);

        RecomputeHandScale();
        SnapToHomePose();
    }

    private void HandleGridRecalculated()
    {
        if (screenToGrid == null) return;
        if (screenToGrid.CellSize != lastCellSize)
        {
            BuildVisual();
            RecomputeHandScale();
            SnapToHomePose();
        }
    }

    private void BuildVisual()
    {
        if (blocks != null)
        {
            for (int i = 0; i < blocks.Length; i++)
                if (blocks[i] != null) Destroy(blocks[i].gameObject);
        }

        if (piece == null || !piece.IsValid() || blockPrefab == null || screenToGrid == null)
        {
            blocks = null;
            baseColors = null;
            return;
        }

        Vector2 cell = screenToGrid.CellSize;
        lastCellSize = cell;

        blocks = new Image[piece.blocks.Length];
        baseColors = new Color[piece.blocks.Length];

        for (int i = 0; i < piece.blocks.Length; i++)
        {
            Image img = Instantiate(blockPrefab, transform);
            img.raycastTarget = false;

            if (piece.tileSprite != null) img.sprite = piece.tileSprite;
            img.color = piece.tileColor;
            img.material = (piece.tileMaterial != null) ? piece.tileMaterial : null;

            RectTransform r = (RectTransform)img.transform;
            r.anchorMin = r.anchorMax = new Vector2(0.5f, 0.5f);
            r.pivot = new Vector2(0.5f, 0.5f);
            r.sizeDelta = cell;

            Vector2Int rel = piece.blocks[i] - piece.dragAnchor;
            r.anchoredPosition = new Vector2(rel.x * cell.x, rel.y * cell.y);

            blocks[i] = img;
            baseColors[i] = img.color;
        }

        // root rect interaction size = piece bounds
        ComputeAndApplyRootSize(cell);
    }

    private void ComputeAndApplyRootSize(Vector2 cell)
    {
        if (piece == null || piece.blocks == null || piece.blocks.Length == 0) return;

        int minX = int.MaxValue, maxX = int.MinValue;
        int minY = int.MaxValue, maxY = int.MinValue;

        for (int i = 0; i < piece.blocks.Length; i++)
        {
            Vector2Int rel = piece.blocks[i] - piece.dragAnchor;
            minX = Mathf.Min(minX, rel.x);
            maxX = Mathf.Max(maxX, rel.x);
            minY = Mathf.Min(minY, rel.y);
            maxY = Mathf.Max(maxY, rel.y);
        }

        float w = (maxX - minX + 1) * cell.x;
        float h = (maxY - minY + 1) * cell.y;

        rect.sizeDelta = new Vector2(w, h);
        rect.pivot = new Vector2(0.5f, 0.5f);
    }

    // 슬롯에 “맞게” 보이도록 handScale 계산
    private void RecomputeHandScale()
    {
        if (!hasHome || piece == null || !piece.IsValid() || screenToGrid == null) { handScale = 1f; return; }

        Vector2 cell = screenToGrid.CellSize;
        Vector2 pieceSize = rect.sizeDelta; // 이미 bounds 기반

        // slotSize 기준으로 piece가 들어가도록 scale 계산
        float sx = (pieceSize.x <= 0.01f) ? 1f : (homeSlotSize.x * handPaddingFactor) / pieceSize.x;
        float sy = (pieceSize.y <= 0.01f) ? 1f : (homeSlotSize.y * handPaddingFactor) / pieceSize.y;

        handScale = Mathf.Clamp01(Mathf.Min(sx, sy)); // 0~1
        if (handScale <= 0f) handScale = 1f;
    }

    private void SnapToHomePose()
    {
        if (!hasHome) return;

        rect.anchoredPosition = homeAnchoredPos;
        rect.localScale = Vector3.one * handScale;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (canvasGroup != null) canvasGroup.blocksRaycasts = false;
        transform.SetAsLastSibling();

        // 드래그 시작 = 보드 기준 크기(1배)로 “커짐”
        rect.localScale = Vector3.one;

        // 커진 상태 기준으로 grabOffset 계산(점프/툭 내려감 근본 해결)
        RectTransformUtility.ScreenPointToLocalPointInRectangle(dragLayer, eventData.position, uiCamera, out var pointerLocal);
        grabOffset = rect.anchoredPosition - pointerLocal;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (piece == null || !piece.IsValid() || blocks == null || screenToGrid == null || game == null)
            return;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(dragLayer, eventData.position, uiCamera, out var pointerLocal);
        rect.anchoredPosition = pointerLocal + grabOffset;

        if (screenToGrid.TryGetGridPos(eventData.position, out var hover))
        {
            Vector2Int origin = hover - piece.dragAnchor;
            bool canPlace = game.CanPlace(piece, origin);
            ApplyTintFactor(canPlace ? validFactor : invalidFactor);
        }
        else
        {
            ApplyTintFactor(Color.white);
        }
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (canvasGroup != null) canvasGroup.blocksRaycasts = true;

        if (piece == null || !piece.IsValid() || blocks == null || screenToGrid == null || game == null)
        {
            SnapToHomePose();
            ApplyTintFactor(Color.white);
            return;
        }

        if (screenToGrid.TryGetGridPos(eventData.position, out var hover))
        {
            Vector2Int origin = hover - piece.dragAnchor;

            var turn = game.TryPlace(piece, origin);
            if (turn.success)
            {
                ApplyTintFactor(Color.white);
                OnPlaced?.Invoke(this);

                // 배치 성공 후 손패 위치/스케일로 복귀 (그리고 HandController가 SetPiece로 리필)
                SnapToHomePose();
                return;
            }
        }

        // 실패 → 손패로 복귀
        SnapToHomePose();
        ApplyTintFactor(Color.white);
    }

    private void ApplyTintFactor(Color factor)
    {
        if (blocks == null || baseColors == null) return;

        for (int i = 0; i < blocks.Length; i++)
        {
            Color b = baseColors[i];
            blocks[i].color = new Color(b.r * factor.r, b.g * factor.g, b.b * factor.b, b.a * factor.a);
        }
    }
}
