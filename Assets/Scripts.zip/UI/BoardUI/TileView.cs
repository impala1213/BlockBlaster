using UnityEngine;
using UnityEngine.UI;

public sealed class TileView : MonoBehaviour
{
    private RectTransform rect;
    private Image image;

    private void Awake()
    {
        rect = (RectTransform)transform;
        image = GetComponent<Image>();
        if (image != null) image.raycastTarget = false;
    }

    public void ApplyLayout(Vector2 anchoredPos, Vector2 size)
    {
        rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.sizeDelta = size;
        rect.anchoredPosition = anchoredPos;
    }

    public void ApplyVisual(PieceDefinition piece)
    {
        if (image == null) return;

        if (piece != null && piece.tileSprite != null)
            image.sprite = piece.tileSprite;

        image.color = (piece != null) ? piece.tileColor : Color.white;

        if (piece != null && piece.tileMaterial != null)
            image.material = piece.tileMaterial;
        else
            image.material = null;
    }
}
