using UnityEngine;

[CreateAssetMenu(menuName = "BlockBlast/Piece Definition", fileName = "Piece_")]
public sealed class PieceDefinition : ScriptableObject
{
    public string pieceId;

    [Header("Shape blocks offsets")]
    public Vector2Int[] blocks;

    [Header("Drag anchor (must be one of blocks)")]
    public Vector2Int dragAnchor = Vector2Int.zero;

    [Header("Visual (for BOTH drag + placed tiles)")]
    public Sprite tileSprite;              // ���忡 ������ Ÿ�� ��������Ʈ
    public Color tileColor = Color.white;  // ���忡 ������ Ÿ�� ��
    public Material tileMaterial;          // ����(Ư�� ȿ�� ������)

    public bool IsValid()
    {
        if (blocks == null || blocks.Length == 0) return false;

        bool anchorFound = false;
        for (int i = 0; i < blocks.Length; i++)
        {
            if (blocks[i] == dragAnchor) anchorFound = true;
        }
        return anchorFound;
    }
}
