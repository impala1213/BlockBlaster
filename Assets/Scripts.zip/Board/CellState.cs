public enum CellState
{
    Empty = 0,
    Filled = 1
}
