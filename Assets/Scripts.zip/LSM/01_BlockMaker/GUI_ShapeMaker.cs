using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

[CustomEditor(typeof(ShapeMaker))]
public class GUI_ShapeMaker : Editor
{
    private ShapeMaker shapeM;
    [SerializeField] private SerializedProperty _data;

    [SerializeField] private SerializedProperty PD_arr;

    [SerializeField] private SerializedProperty _pieceId;
    [SerializeField] private SerializedProperty _blocks;
    [SerializeField] private SerializedProperty _origin;
    [SerializeField] private SerializedProperty _sprite;
    [SerializeField] private SerializedProperty _color;
    [SerializeField] private SerializedProperty _mat;

    [SerializeField] private SerializedProperty _name;
    [SerializeField] private SerializedProperty _isOverwrite, _isOverlap;

    PieceDefinition _selectData;

    float box_size = 20f;
    SerializedProperty cells;

    private int select_num = -1;

    bool b;
    private SerializedProperty w_, h_ ;
    private SerializedProperty s_x_, s_y_;
    bool isDrag, isTrue;

    string prev_name, prev_id;



    private void OnEnable()
    {
        shapeM = (ShapeMaker)target;
        _name = serializedObject.FindProperty("_name");
        _data = serializedObject.FindProperty("_data");
        PD_arr = serializedObject.FindProperty("pd_arr");

        _pieceId = serializedObject.FindProperty("_pieceId");
        _blocks = serializedObject.FindProperty("_blocks");
        _origin = serializedObject.FindProperty("_origin");
        _sprite = serializedObject.FindProperty("_sprite");
        _color = serializedObject.FindProperty("_color");
        _mat = serializedObject.FindProperty("_mat");


        cells = serializedObject.FindProperty("slot_cell");
        w_ = serializedObject.FindProperty("w");
        h_ = serializedObject.FindProperty("h");
        s_x_ = serializedObject.FindProperty("s_x");
        s_y_ = serializedObject.FindProperty("s_y");
        _isOverwrite = serializedObject.FindProperty("isOverwrite");
        _isOverlap = serializedObject.FindProperty("isOverlap");
        shapeM.Img_Enable(false);
        shapeM.Get_Files();
    }

    private void OnDisable()
    {
        shapeM.Img_Enable(false);
    }

    public override void OnInspectorGUI()
    {
        //base.OnInspectorGUI();

        serializedObject.Update();

        List<string> d_arr = shapeM.FileNames;
        d_arr.Add("���� ����.");


        EditorGUILayout.Space(20);
        GUIStyle titleStyle = new GUIStyle(EditorStyles.label);
        titleStyle.fontSize = 16;
        titleStyle.fontStyle = FontStyle.Bold;

        GUILayout.BeginHorizontal();
        GUILayout.Label("������ ����", titleStyle);
        int idx = EditorGUILayout.Popup(select_num, d_arr.ToArray());
        GUILayout.EndHorizontal();
        if (idx != select_num)
        {
            shapeM.Select_Data(idx);
            select_num = idx;
            shapeM.Setting_Data();
            shapeM.Img_Enable(true);
        }

        if (idx >= 0)
        {
            GUILayout.BeginVertical(EditorStyles.helpBox);
            DisplayField();

            GUILayout.Space(15);

            // ��ư �ʱ�ȭ.
            if(prev_name != _name.stringValue)
            {
                _isOverwrite.boolValue = false;
                prev_name = _name.stringValue;
            }
            if(prev_id != _pieceId.stringValue)
            {
                _isOverlap.boolValue = false;
                prev_id = _pieceId.stringValue;
            }

            GUIStyle buttonStyle = new GUIStyle(GUI.skin.button);
            buttonStyle.richText = true;
            // ��ư
            if (!_isOverlap.boolValue && !_isOverwrite.boolValue)
            {
                if (GUILayout.Button("Save Shape", buttonStyle))
                {
                    shapeM.Save_Data();
                }
            }
            else if (_isOverlap.boolValue)
            {
                if (GUILayout.Button("<color=red>ID�� �ߺ��Ǿ����ϴ�.</color>", buttonStyle))
                { }
            }
            else if (_isOverwrite.boolValue)
            {
                if (GUILayout.Button("<color=yellow>�ߺ��� �̸��� �����մϴ�. �����ڽ��ϱ�?</color>", buttonStyle))
                { shapeM.Save_Data(); }
            }

                GUILayout.EndVertical();
        }
        EditorGUILayout.Space(20);
        serializedObject.ApplyModifiedProperties();

    }


    private void DisplayField()
    {
        GUIStyle titleStyle = new GUIStyle(EditorStyles.label);
        titleStyle.fontSize = 16;
        titleStyle.fontStyle = FontStyle.Bold;

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.PropertyField(_data);
        EditorGUI.EndDisabledGroup();

        GUILayout.Space(5);
        GUILayout.Label("������ ���� �̸�.", titleStyle);
        EditorGUILayout.PropertyField(_name);

        GUILayout.Space(13);
        //GUILayout.Label("���� ����.");
        //GUILayout.Space(5);
        GUILayout.Label("�긯 ���̵�. (���� �ĺ��� ����.)", titleStyle);
        EditorGUILayout.PropertyField(_pieceId);

        GUILayout.Space(5);
        GUILayout.Label("��� �����.", titleStyle);

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.PropertyField(_blocks);
        EditorGUI.EndDisabledGroup();

        // Ŭ������ ����� ���� ����.
        Point_MouseClick();
        // ȸ�����.
        GUILayout.BeginHorizontal(EditorStyles.helpBox);
        if (GUILayout.Button("�ݽð� ����"))
        { shapeM.Rotate_Block(false); }

        // �������.
        GUILayout.BeginVertical();
        if (GUILayout.Button("���� ����"))
        { shapeM.Reversal_Block(true); }
        if (GUILayout.Button("�¿� ����"))
        { shapeM.Reversal_Block(false); }
        GUILayout.EndVertical();

        //ȸ�����
        if (GUILayout.Button("�ð� ����"))
        { shapeM.Rotate_Block(true); }
        GUILayout.EndHorizontal();
        

        GUILayout.Space(5);
        GUILayout.Label("����. ������ �߽���.", titleStyle);
        EditorGUILayout.PropertyField(_origin);
        int d_w = Mathf.FloorToInt(w_.intValue / 2);
        int d_h = Mathf.FloorToInt(h_.intValue / 2);
        _origin.vector2IntValue = new Vector2Int( Mathf.Clamp(_origin.vector2IntValue.x,-d_w,d_w), 
            Mathf.Clamp(_origin.vector2IntValue.y,-d_h, d_h)  );

        GUILayout.Space(15);
        GUILayout.Label("�긯�� ���� ����. ��������Ʈ, ����, ����.", titleStyle);
        EditorGUILayout.PropertyField(_sprite);
        EditorGUILayout.PropertyField(_color);
        EditorGUILayout.PropertyField(_mat);

        shapeM.CheckSprite(false);
    }

    private void Point_MouseClick()
    {


        EditorGUILayout.Space(5f);

        int w = w_.intValue, h = h_.intValue;
        int s_x = s_x_.intValue, s_y = s_y_.intValue;
        float space = 1f;

        Vector2Int[] body_pointlist = shapeM.Data.blocks;

        Rect picker_rect = GUILayoutUtility.GetRect(box_size, box_size, box_size, box_size,
            GUIStyle.none, GUILayout.ExpandWidth(false));

        if (cells.arraySize != w * h)
        { cells.arraySize = w * h; }



        // ���콺 Ŭ�� ���� �̺�Ʈ�� �޾ƿ�.
        Event e = Event.current;

        for(int i = h-1; i >=0; i--)
        {
            EditorGUILayout.BeginHorizontal();
            for(int j = 0; j<w; j++)
            {
                int idx = i * w + j;

                SerializedProperty d_cell = cells.GetArrayElementAtIndex(idx);

                bool isOrigin = _origin.vector2IntValue.x + s_x == j && _origin.vector2IntValue.y+s_y == i;

                // üũ�� �ڽ� �׸���
                Rect rect = GUILayoutUtility.GetRect(
                    box_size, box_size,
                    GUILayout.Width(box_size),
                    GUILayout.Height(box_size));

                Rect drawRect = new Rect(
                    rect.x + space * 0.5f,
                    rect.y + space * 0.5f,
                    rect.width - space,
                    rect.height - space
                    );
                EditorGUI.DrawRect(drawRect, d_cell.boolValue ? (isOrigin?Color.yellow: Color.green ): Color.gray);

                // ���콺 ��ġ�� �ش� ���� �ȿ� �ִٸ�
                if (rect.Contains(e.mousePosition))
                {
                    if (e.type == EventType.MouseDown && e.button == 0)
                    {
                        isDrag = true;
                        isTrue = !d_cell.boolValue;
                        d_cell.boolValue = isTrue;
                        e.Use();
                    }
                    else if (e.type == EventType.MouseDrag && isDrag)
                    {
                        d_cell.boolValue = isTrue;
                        e.Use();
                    }
                }

                if (isOrigin)
                { d_cell.boolValue = true; }

            }

            EditorGUILayout.EndHorizontal();
        }


        if (e.type == EventType.MouseUp)
        { isDrag = false; }
    }

}
